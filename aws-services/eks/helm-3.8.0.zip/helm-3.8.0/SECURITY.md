# Helm Security Reporting and Policy

The Helm project has [a common process and policy that can be found here](https://github.com/helm/community/blob/master/SECURITY.md).